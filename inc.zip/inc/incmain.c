/**
 * incmain.c
 * dummy project so CCS will let you see these files
 */
void main(void){

}
